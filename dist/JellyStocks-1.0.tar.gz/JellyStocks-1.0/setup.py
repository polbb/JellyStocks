from setuptools import setup

setup(
    name='JellyStocks',
    version='1.0',
)