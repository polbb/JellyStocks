# JellyStocks
Portfolio optimization using Jellyfish Search Optimizer
## Under Construction
